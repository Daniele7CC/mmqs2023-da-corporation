package net.sf.rails.ui.swing;

import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.stream.IntStream;

import javax.swing.*;
import javax.swing.plaf.FontUIResource;

import net.sf.rails.game.*;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.collect.Iterables;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.PatternLayout;
import ch.qos.logback.classic.spi.LoggingEvent;
import ch.qos.logback.core.read.CyclicBufferAppender;
import net.sf.rails.common.Config;
import net.sf.rails.common.ConfigManager;
import net.sf.rails.common.DisplayBuffer;
import net.sf.rails.common.GuiDef;
import net.sf.rails.common.GuiHints;
import net.sf.rails.common.LocalText;
import net.sf.rails.common.notify.Discord;
import net.sf.rails.common.notify.Slack;
import net.sf.rails.game.financial.Bank;
import net.sf.rails.game.financial.StockRound;
import net.sf.rails.game.round.RoundFacade;
import net.sf.rails.game.state.Observer;
import net.sf.rails.sound.SoundManager;
import net.sf.rails.ui.swing.elements.CheckBoxDialog;
import net.sf.rails.ui.swing.elements.DialogOwner;
import net.sf.rails.ui.swing.elements.MessageDialog;
import net.sf.rails.ui.swing.elements.NonModalDialog;
import net.sf.rails.ui.swing.elements.RadioButtonDialog;
import net.sf.rails.util.Util;
import rails.game.action.*;

/**
 * This class is called by main() and loads all of the UI components
 */
public class GameUIManager implements DialogOwner {
    protected StatusWindow statusWindow;
    protected ReportWindow reportWindow;
    protected ConfigWindow configWindow;
    protected ORUIManager orUIManager;
    protected ORWindow orWindow; // TEMPORARY  -- EV: Why?
    private StartRoundWindow startRoundWindow;

    protected JDialog currentDialog = null;

    protected StockChartWindow stockChartWindow;

    protected PossibleAction currentDialogAction = null;

    protected RailsRoot railsRoot;
    protected PossibleAction lastAction;
    protected ActionPerformer activeWindow = null;
    protected StartRound startRound;

    protected RoundFacade currentRound;
    protected RoundFacade previousRound;
    protected Class<? extends RoundFacade> previousRoundType = null;
    protected Class<? extends RoundFacade> currentRoundType = null;
    protected GuiHints uiHints = null;
    protected String previousRoundName;
    protected String currentRoundName;

    protected static final String DEFAULT_SAVE_DIRECTORY = "save";
    protected static final String DEFAULT_SAVE_PATTERN = "yyyyMMdd_HHmm";
    public static final String DEFAULT_SAVE_EXTENSION = "rails";

    public static final String DEFAULT_SAVE_POLLING_EXTENSION = "lrails";
    protected static final String NEXT_PLAYER_SUFFIX = "NEXT_PLAYER";
    protected static final String CURRENT_ROUND_SUFFIX = "CURRENT_ROUND";

    protected String saveDirectory;
    protected String savePattern;
    protected String saveExtension;
    protected String savePrefix;
    protected String saveSuffixSpec = "";
    protected String saveSuffix = "";
    protected String providedName = null;
    protected SimpleDateFormat saveDateTimeFormat;

    protected boolean autoSaveLoadInitialized = false;
    protected int autoSaveLoadStatus = 0;
    protected int autoSaveLoadPollingInterval = 30;
    protected AutoLoadPoller autoLoadPoller = null;
    protected boolean myTurn = true;
    protected String lastSavedFilename = null;
    protected String localPlayerName = "";

    protected boolean gameWasLoaded = false;

    protected WindowSettings windowSettings;

    protected boolean configuredStockChartVisibility = false;

    protected boolean previousStockChartVisibilityHint;
    protected boolean previousStatusWindowVisibilityHint;
    protected boolean previousORWindowVisibilityHint;

    protected boolean previousResult;

    // Player order
//    protected PlayerOrderView playerOrderView;
    /**
     * Player names set at time of initialisation or after reordering.
     * <p> To be used as a reference to the current player order as shown in the UI.
     * Note, that getPlayers() currently calls the game engine directly, and
     * therefore updates before the UI gets notice via the playerOrderView.
     */
    protected List<String> currentGuiPlayerNames;

    /* Keys of dialogs owned by this class */
    public static final String COMPANY_START_PRICE_DIALOG = "CompanyStartPrice";
    public static final String SELECT_COMPANY_DIALOG = "SelectCompany";
    public static final String REPAY_LOANS_DIALOG = "RepayLoans";
    public static final String EXCHANGE_TOKENS_DIALOG = "ExchangeTokens";
    public static final String ADJUST_SHARE_PRICE_DIALOG = "AdjustSharePrice";

    private static final Logger log = LoggerFactory.getLogger(GameUIManager.class);

    private SplashWindow splashWindow = null;

    public GameUIManager() {
    }

    public void init(RailsRoot root, boolean wasLoaded, SplashWindow splashWindow) {
        this.splashWindow = splashWindow;
        splashWindow.notifyOfStep(SplashWindow.STEP_INIT_UI);

        this.railsRoot = root;
        uiHints = railsRoot.getGameManager().getUIHints();
        savePrefix = railsRoot.getGameName();
        gameWasLoaded = wasLoaded;

        initWindowSettings();
        initSaveSettings();
        initFontSettings();

        configuredStockChartVisibility = "yes".equalsIgnoreCase(Config.get("stockchart.window.open"));

//        playerOrderView = new PlayerOrderView();
        currentGuiPlayerNames = new ArrayList<>();
        for (Player player : getPlayers()) {
            currentGuiPlayerNames.add(player.getId());
        }

        localPlayerName = System.getProperty("local.player.name");
        if (!Util.hasValue(localPlayerName)) {
            localPlayerName = Config.get("local.player.name");
        }
        if (autoSaveLoadStatus > 0) {
            myTurn = getCurrentPlayer().getId().equals(localPlayerName);
            log.debug("starting game with my turn: {}", myTurn);
        }

        OpenGamesManager.getInstance().addGame(this);
    }

    private void initWindowSettings() {
        windowSettings = new WindowSettings(railsRoot.getGameName());
        windowSettings.load();
    }

    public static boolean confirmQuit(JFrame parent) {
        if ( StringUtils.isNotBlank(Config.get("skip_confirm_quit")) && Util.parseBoolean(Config.get("skip_confirm_quit"))) {
            // user has a confirm_quit preference and it's not set
            return true;
        }
        return JOptionPane.showConfirmDialog(parent, LocalText.getText("CLOSE_WINDOW"),
                LocalText.getText("Select"), JOptionPane.OK_CANCEL_OPTION) == JOptionPane.OK_OPTION;
    }

    public void closeGame() {
        if ( myTurn ) {
            // TODO: confirm game close if in turn and polling?
        }
        OpenGamesManager.getInstance().removeGame(this);
        getWindowSettings().save();
        if ( startRoundWindow != null ) {
            startRoundWindow.close();
        }
        if ( statusWindow != null ) {
            statusWindow.dispose();
        }
        if ( reportWindow != null ) {
            reportWindow.dispose();
        }
        if ( orWindow != null ) {
            orWindow.dispose();
        }
        if ( configWindow != null ) {
            configWindow.dispose();
        }
        if ( currentDialog != null ) {
            currentDialog.dispose();
        }
        if ( autoLoadPoller != null ) {
            autoLoadPoller.setActive(false);
            autoLoadPoller.close();
        }
        // TODO: terminate things like Discord

        // clean up config items that are game play specific (ie like Discord)
        ConfigManager.getInstance().clearTransientConfig();
    }

    public void terminate() {
        getWindowSettings().save();
        // TODO: save relocation and resizing information of the FKStockChartWindow

        if (orWindow != null) orWindow.saveLayout();
        System.exit(0);
    }

    public WindowSettings getWindowSettings() {
        return windowSettings;
    }

    private void initSaveSettings() {
        saveDirectory = Config.get("save.directory");
        if (!Util.hasValue(saveDirectory)) {
            saveDirectory = DEFAULT_SAVE_DIRECTORY;
        }
        savePattern = Config.get("save.filename.date_time_pattern");
        if (!Util.hasValue(savePattern)) {
            savePattern = DEFAULT_SAVE_PATTERN;
        }
        saveDateTimeFormat = new SimpleDateFormat(savePattern);
        saveExtension = Config.get("save.filename.extension");
        if (!Util.hasValue(saveExtension)) {
            saveExtension = DEFAULT_SAVE_EXTENSION;
        }
        String timezone = Config.get("save.filename.date_time_zone");
        // Default is local time
        if (Util.hasValue(timezone)) {
            saveDateTimeFormat.setTimeZone(TimeZone.getTimeZone(timezone));
        }
        saveSuffixSpec = Config.get("save.filename.suffix");
        if (!Util.hasValue(saveSuffixSpec) || saveSuffixSpec.equals(NEXT_PLAYER_SUFFIX)) {
            saveSuffix = getPlayers().get(0).getId();
        } else if (saveSuffixSpec.equals(CURRENT_ROUND_SUFFIX)) {
            if (currentRound != null) {
                saveSuffix = currentRound.getRoundName();
            } else {
                saveSuffix = "";
            }
        } else { // otherwise use specified suffix
            saveSuffix = saveSuffixSpec;
        }
        log.debug("Initial save suffix: {}", saveSuffix);

        String str = Config.get("save.auto.enabled");
        autoSaveLoadStatus = "yes".equals(str) ? AutoLoadPoller.ON : AutoLoadPoller.OFF;
        str = Config.get("save.auto.interval");
        if (Util.hasValue(str)) {
            autoSaveLoadPollingInterval = Integer.parseInt(str);
        }
    }

    private void initFontSettings() {
        // font settings, can be game specific
        String fontType = Config.getGameSpecific(railsRoot.getGameName(), "font.ui.name");
        Font font = null;
        if (Util.hasValue(fontType)) {
            boolean boldStyle = true;
            String fontStyle = Config.getGameSpecific(railsRoot.getGameName(), "font.ui.style");
            if (Util.hasValue(fontStyle)) {
                if (fontStyle.equalsIgnoreCase("plain")) {
                    boldStyle = false;
                }
            }
            if (boldStyle) {
                font = new Font(fontType, Font.BOLD, 12);
            } else {
                font = new Font(fontType, Font.PLAIN, 12);
            }
            log.debug("Change text fonts globally to {} / {}", font.getName(), boldStyle ? "Bold" : "Plain");
        }

        log.debug("Change text fonts to relative scale {}", GUIGlobals.getFontsScale());
        changeGlobalFont(font, GUIGlobals.getFontsScale());
    }


    public void gameUIInit(boolean newGame) {
        splashWindow.notifyOfStep(SplashWindow.STEP_STOCK_CHART);
        stockChartWindow = new StockChartWindow(this);

        splashWindow.notifyOfStep(SplashWindow.STEP_REPORT_WINDOW);

        boolean staticReportWindow = Config.get("report.window.type").equalsIgnoreCase("static");
        reportWindow = new ReportWindow(this, staticReportWindow);

        orWindow = new ORWindow(this, splashWindow);
        orUIManager = orWindow.getORUIManager();

        splashWindow.notifyOfStep(SplashWindow.STEP_STATUS_WINDOW);
        String statusWindowClassName = getClassName(GuiDef.ClassName.STATUS_WINDOW);
        try {
            Class<? extends StatusWindow> statusWindowClass =
                    Class.forName(statusWindowClassName).asSubclass(StatusWindow.class);
            statusWindow = statusWindowClass.newInstance();

            //            GraphicsEnvironment ge = GraphicsEnvironment.
            //            getLocalGraphicsEnvironment();
            //            GraphicsDevice[] gs = ge.getScreenDevices();
            //            log.debug("ScreenDevices = " + Arrays.toString(gs));
            //            statusWindow = statusWindowClass.getConstructor(GraphicsConfiguration.class).newInstance(gs[1].getDefaultConfiguration());

            statusWindow.init(this);
        } catch (Exception e) {
            log.error("Cannot instantiate class {}", statusWindowClassName, e);
            System.exit(1);
        }

        // removed for reloaded games to avoid double revenue calculation
        if (newGame) {
            splashWindow.notifyOfStep(SplashWindow.STEP_INIT_NEW_GAME);
            updateUI();
        }

        reportWindow.scrollDown();

        // define configWindow
        splashWindow.notifyOfStep(SplashWindow.STEP_CONFIG_WINDOW);
        configWindow = new ConfigWindow(statusWindow);
        configWindow.init(true);

        // notify sound manager of game initialization
        splashWindow.notifyOfStep(SplashWindow.STEP_INIT_SOUND);
        SoundManager.notifyOfGameInit(railsRoot);

        new Discord(this, railsRoot);
        new Slack(this, railsRoot);
    }

    public void startLoadedGame() {
        gameUIInit(false); // false indicates reload

        splashWindow.notifyOfStep(SplashWindow.STEP_INIT_LOADED_GAME);
        processAction(new NullAction(getRoot(), NullAction.Mode.START_GAME));
        statusWindow.setGameActions();
    }

    public boolean processAction(PossibleAction action) {
        boolean result;

        // In some cases an Undo requires a different follow-up
        lastAction = action;

        if (action == null) {
            // If the action is null, we can skip processing
            // and continue with following up a previous action.
            // This occurs after a nonmodal Message dialog.
            result = previousResult;

        } else {
            Player oldPlayer = getCurrentPlayer();

            // Notify the Sound Manager about this action, as it could lead to
            // playing sfx or music.
            // Notification has to be done before action processing so that
            // resulting sfx are played in the correct order (first the action
            // related sfx and then model-change related sfx)
            SoundManager.notifyOfActionProcessing(railsRoot, action);

            // Process the action on the server
            result = previousResult = processOnServer(action);

            // Process any autosaving and turn relinquishing, resp. autoloading and turn pickup
            if (autoSaveLoadInitialized && autoSaveLoadStatus != AutoLoadPoller.OFF) {
                boolean wasMyTurn = oldPlayer.getId().equals(localPlayerName);
                Player newPlayer = getCurrentPlayer();
                myTurn = newPlayer.getId().equals(localPlayerName);
                log.debug("players o:{}/c:{} myTurn:{}", oldPlayer.getId(), newPlayer.getId(), myTurn);
                if (newPlayer != oldPlayer) {
                    if (wasMyTurn && !myTurn) {
                        autoSave(newPlayer.getId());
                        autoLoadPoller.setLastSavedFilename(lastSavedFilename);
                        autoLoadPoller.setActive(true);
                        log.info("Relinquishing turn to {}", newPlayer.getId());
                    } else if (!wasMyTurn && myTurn) {
                        autoLoadPoller.setActive(false);

                        if ( Taskbar.getTaskbar().isSupported(Taskbar.Feature.USER_ATTENTION) ) {
                            Taskbar.getTaskbar().requestUserAttention(true, false);
                        } else {
                            setCurrentDialog(new MessageDialog(null, this,
                                            (JFrame) activeWindow,
                                            LocalText.getText("Message"),
                                            LocalText.getText("YourTurn", localPlayerName)),
                                    null);
                        }

                        log.info("Resuming turn as {}", localPlayerName);
                    } else {
                        log.info("{} now has the turn", newPlayer.getId());
                    }
                } else {
                    // first time through after a game load needs to set myTurn
                    log.info("{} keeps the turn", oldPlayer.getId());
                }
            }
        }
        // Is this perhaps the right place to display messages...?
        if (getDisplayBuffer().getAutoDisplay()) {
            if (displayServerMessage()) {
                // Interrupt processing.
                // Will be continued via dialogActionPerformed().
                return true;
            }
        }

        // Check in which round we are now,
        // and make sure that the right window is active.
        updateUI();

        statusWindow.initGameActions();
        reportWindow.setActions();
        if (!myTurn) return true;
        statusWindow.setGameActions();
        statusWindow.setCorrectionMenu();

        // Is this perhaps the right place to display messages...?
        /* See above for what is perhaps a better place
        if (getDisplayBuffer().getAutoDisplay()) {
            if (displayServerMessage()) {
                // Interrupt processing.
                // Will be continued via dialogActionPerformed().
                return true;
            }
        }*/

        // display the end of game report
        if (railsRoot.getGameManager().isGameOver()) statusWindow.endOfGameReport();

        if (!result) return false;

        return activeWindow.processImmediateAction();
    }
    public void adjustSharePrice (AdjustSharePrice action) {

        int optionsCount = action.getDirections().size();
        String[] options = new String[optionsCount+1];
        options[0] = LocalText.getText("None");

        Iterator<AdjustSharePrice.Direction> iterator = action.getDirections().iterator();
        int i = 0;
        while (iterator.hasNext()) {
            options[++i] = LocalText.getText("AdjustDirection", iterator.next());
        }

        RadioButtonDialog dialog = new RadioButtonDialog (ADJUST_SHARE_PRICE_DIALOG,
                this, statusWindow,
                LocalText.getText("AdjustSharePrice", action.getCompanyName()),
                LocalText.getText("SelectPriceAdjustment", action.getCompanyName()),
                options, 0);
        setCurrentDialog (dialog, action);

    }



    protected boolean processOnServer(PossibleAction action) {
        boolean result;

        action.setActed();
        action.setPlayerName(getCurrentPlayer().getId());

        log.debug("==Passing to server: {}", action);

        // Process the action on the server
        result = railsRoot.getGameManager().process(action);

        // Follow-up the result
        log.debug("==Result from server: {}", result);

        return result;
    }

    public boolean displayServerMessage() {
        String[] message = getDisplayBuffer().get();
        if (message != null) {
            setCurrentDialog(new MessageDialog(null, this,
                            (JFrame) activeWindow,
                            LocalText.getText("Message"),
                            "<html>" + Util.join(message, "<br>")),
                    null);
            return true;
        }
        return false;
    }

    public void updateUI() {
        previousRoundType = currentRoundType;
        previousRoundName = currentRoundName;
        previousRound = currentRound;

        currentRound = railsRoot.getGameManager().getCurrentRound();
        currentRoundName = currentRound.toString();
        log.debug("Current round={}, previous round={}", currentRoundName, previousRoundName);

        //currentRoundType = uiHints.getCurrentRoundType();
        currentRoundType = currentRound.getClass();

        /* Process actual round type changes */
        if (previousRoundType != currentRoundType) {

            /* Finish previous round UI processing */
            if (previousRoundType != null) {
                /* close current dialog */
                setCurrentDialog(null, null);

                if (StockRound.class.isAssignableFrom(previousRoundType)) {
                    log.debug("UI leaving Stock Round {}", previousRoundName);
                    statusWindow.finishRound();
                } else if (StartRound.class.isAssignableFrom(previousRoundType)) {
                    log.debug("UI leaving Start Round {}", previousRoundName);
                    if (startRoundWindow != null) {
                        startRoundWindow.close();
                        startRoundWindow = null;
                    }
                } else if (OperatingRound.class.isAssignableFrom(previousRoundType)) {
                    log.debug("UI leaving Operating Round {}", previousRoundName);
                    orUIManager.finish();
                } else if (SwitchableUIRound.class.isAssignableFrom(previousRoundType)) {
                    log.debug("UI leaving switchable round type {}", previousRoundName);
                }
            }
        }

        if (currentRound != previousRound) {
            // Start the new round UI processing
            if (StartRound.class.isAssignableFrom(currentRoundType)) {
                log.debug("UI entering Start Round {}", currentRoundName);
                startRound = (StartRound) currentRound;
                if (startRoundWindow == null) {
                    //startRoundWindow = new StartRoundWindow(startRound, this);
                    String startRoundWindowClassName = getClassName(GuiDef.ClassName.START_ROUND_WINDOW);
                    try {
                        Class<? extends StartRoundWindow> startRoundWindowClass =
                                Class.forName(startRoundWindowClassName).asSubclass(StartRoundWindow.class);
                        startRoundWindow = startRoundWindowClass.newInstance();
                        startRoundWindow.init(startRound, this);
                    } catch (Exception e) {
                        log.error("Cannot instantiate class {}", startRoundWindowClassName, e);
                        System.exit(1);
                    }
                }

            } else if (StockRound.class.isAssignableFrom(currentRoundType)) {
                log.debug("UI entering Stock Round type {}", currentRoundName);
                // Not sure if this is the right place
                // but it is required for the 1837 CoalExchangeRound
                statusWindow.getGameStatus().initGameSpecificActions ();

            } else if (OperatingRound.class.isAssignableFrom(currentRoundType)) {
                log.debug("UI entering Operating Round type {}", currentRoundName);
                orUIManager.initOR((OperatingRound) currentRound);

            } else if (SwitchableUIRound.class.isAssignableFrom(currentRoundType)) {
                log.debug("UI entering switchable round type {}", currentRoundName);
                statusWindow.pack();
            }
        }

        /* Process visible round type changes */

        // Visibility settings are handled first.
        // Any window not represented in a setting is left unaffected.
        // Each window set visible or already being visible will be put
        // in front as well.
        // As the settings are handled in which these have been entered,
        // this means that this way the window top-to-bottom sequence
        // can be influenced.
        // To make this work, clearVisbilityHints() should be called
        // before each sequence of settings (usually at the start of a round).
        for (GuiHints.VisibilityHint hint : uiHints.getVisibilityHints()) {
            switch (hint.getType()) {
                case STOCK_MARKET:
                    boolean stockChartVisibilityHint = hint.isVisible() || configuredStockChartVisibility;
                    if (stockChartVisibilityHint != previousStockChartVisibilityHint) {
                        stockChartWindow.setVisible(stockChartVisibilityHint);
                        previousStockChartVisibilityHint = stockChartVisibilityHint;
                    }
                    break;
                case STATUS:
                    boolean statusWindowVisibilityHint = hint.isVisible();
                    if (statusWindowVisibilityHint != previousStatusWindowVisibilityHint) {
                        setMeVisible(statusWindow, statusWindowVisibilityHint);
                        previousStatusWindowVisibilityHint = statusWindowVisibilityHint;
                    }
                    if (statusWindowVisibilityHint) setMeToFront(statusWindow);
                    break;
                case MAP:
                    boolean orWindowVisibilityHint = hint.isVisible();
                    if (orWindowVisibilityHint != previousORWindowVisibilityHint) {
                        setMeVisible(orWindow, orWindowVisibilityHint);
                        previousORWindowVisibilityHint = orWindowVisibilityHint;
                    }
                    if (orWindowVisibilityHint) setMeToFront(orWindow);
                    break;
                case START_ROUND:
                    // Handled elsewhere
            }
        }

        //This was always false before ? Bug oversight ?
        boolean correctionOverride = statusWindow.setupFor(currentRound);
        if (correctionOverride) {
            log.debug("Correction overrides active window: status window active");
        }


        // Active window settings are handled last.
        // Side effects: the active window is made visible and put on top.
        if (uiHints.getActivePanel() == GuiDef.Panel.START_ROUND) {
            log.debug("Entering Start Round UI type");
            activeWindow = startRoundWindow;
            setMeVisible(startRoundWindow, true);
            setMeToFront(startRoundWindow);

        } else if (uiHints.getActivePanel() == GuiDef.Panel.STATUS || correctionOverride) {
            log.debug("Entering Stock Round UI type");
            activeWindow = statusWindow;
            stockChartWindow.setVisible(true);
            setMeVisible(statusWindow, true);
            setMeToFront(statusWindow);

        } else if (uiHints.getActivePanel() == GuiDef.Panel.MAP && !correctionOverride) {
            log.debug("Entering Operating Round UI type");
            activeWindow = orWindow;
            setMeVisible(orWindow, true);
            setMeToFront(orWindow);
        }

        if (startRoundWindow != null) {
            log.debug("Updating Start round window ({})", myTurn);
            startRoundWindow.updateStatus(myTurn);
        }
        if (statusWindow != null) {
            log.debug("Updating Stock (status) round window ({})", myTurn);
            statusWindow.updateStatus(myTurn);
        }
        if (orUIManager != null) {
            log.debug("Updating Operating round window ({})", myTurn);
            orUIManager.updateStatus(myTurn);
        }

        // Update the currently visible round window
        // "Switchable" rounds will be handled from subclasses of this class.
        if (StartRoundWindow.class.isAssignableFrom(activeWindow.getClass())) {
            startRoundWindow.setSRPlayerTurn();
        } else if (StatusWindow.class.isAssignableFrom(activeWindow.getClass())) {
        } else if (ORWindow.class.isAssignableFrom(activeWindow.getClass())) {
        }

        updateStatus(activeWindow);
    }

    protected void updatePlayerOrder(List<String> newPlayerOrder) {
        if (startRoundWindow != null) startRoundWindow.updatePlayerOrder(newPlayerOrder);
        if (statusWindow != null) statusWindow.updatePlayerOrder(newPlayerOrder);
        currentGuiPlayerNames = newPlayerOrder;
    }

    public void uncheckMenuItemBox(String itemName) {
        statusWindow.uncheckMenuItemBox(itemName);
    }

    /**
     * Stub, to be overridden in subclasses for special round types
     */
    protected void updateStatus(ActionPerformer activeWindow) {
    }

    public void discardTrains(DiscardTrain dt) {
        PublicCompany c = dt.getCompany();
        String playerName = dt.getPlayerName();
        String companyDirector = dt.getCompany().getPresident().getId();
        Set<Train> trains = dt.getOwnedTrains();
        int size = trains.size() + (dt.isForced() ? 0 : 1);
        List<String> trainOptions = new ArrayList<>(size);
        String[] options = new String[size];
        String prompt = null;

        int j = 0;
        if (!dt.isForced()) {
            trainOptions.add(
                    options[j++] = LocalText.getText("None")
            );
            prompt = LocalText.getText("MayDiscardTrain", c.getId());
        }
        int offset = j;
        for (int i = 0; i < trains.size(); i++) {
            trainOptions.add(
                    options[j++] = LocalText.getText("N_Train",
                            Iterables.get(trains, i).toText())
            );
        }
        //Martin Brumm: 18.7.2017
        //Need to Check that the player informed here is the director
        //Underlying problem is that the director might not be the operating player in the
        //moment and theres no quick way to change that behaviour..
        //Only Chance would be to introduce a new Discard Train Round with complete separate
        //Mechanics

        if (prompt == null) {
            if (playerName.equals(companyDirector)) {
                prompt = LocalText.getText(
                        "HAS_TOO_MANY_TRAINS",
                        playerName,
                        c.getId());
            } else {
                prompt = LocalText.getText(
                        "HAS_TOO_MANY_TRAINS",
                        playerName,
                        c.getId());
                prompt += "\n Please contact the director of the " + c.getId() + " : " + companyDirector + " for guidance.";
            }
        }

        String discardedTrainName =
                (String) JOptionPane.showInputDialog(orWindow,
                        prompt,
                        LocalText.getText("WhichTrainToDiscard"),
                        JOptionPane.QUESTION_MESSAGE, null,
                        options, options[0]);
        if (discardedTrainName != null) {
            int index = trainOptions.indexOf(discardedTrainName);
            // FIXME: Does this work with the new Set defined?
            if (index >= offset) {
                Train discardedTrain =
                        Iterables.get(trains, trainOptions.indexOf(discardedTrainName) - offset);
                dt.setDiscardedTrain(discardedTrain);
            }

            orWindow.process(dt);
        }
    }

    public void exchangeTokens(ExchangeTokens action) {

        int cityNumber;
        String prompt, cityName, hexName, oldCompName;
        String[] ct;
        MapHex hex;
        List<String> options = new ArrayList<>();
        Station station;
        List<ExchangeableToken> oldTokens = action.getTokensToExchange();

        for (ExchangeableToken t : oldTokens) {
            cityName = t.getCityName();
            ct = cityName.split("/");
            hexName = ct[0];
            try {
                cityNumber = Integer.parseInt(ct[1]);
            } catch (NumberFormatException e) {
                cityNumber = 1;
            }
            hex = railsRoot.getMapManager().getHex(hexName);
            station = hex.getStation(cityNumber);
            oldCompName = t.getOldCompanyName();
            options.add(LocalText.getText("ExchangeableToken",
                    oldCompName,
                    hex.toText(),
                    cityNumber,
                    hex.getConnectionString(station)));
        }


        int minNumber = action.getMinNumberToExchange();
        int maxNumber = action.getMaxNumberToExchange();
        if (minNumber == maxNumber) {
            prompt = LocalText.getText("ExchangeTokensPrompt1",
                    minNumber,
                    action.getCompanyName());
        } else {
            prompt = LocalText.getText("ExchangeTokensPrompt2",
                    minNumber, maxNumber,
                    action.getCompanyName());
        }

        if (options.size() > 0) {
            orWindow.setVisible(true);
            orWindow.toFront();

            CheckBoxDialog dialog = new CheckBoxDialog(EXCHANGE_TOKENS_DIALOG,
                    this,
                    orWindow,
                    LocalText.getText("ExchangeTokens"),
                    prompt,
                    options.toArray(new String[0]));
            setCurrentDialog(dialog, action);

        }
    }

    @Override
    public void dialogActionPerformed() {
        dialogActionPerformed(false);
    }

    public void dialogActionPerformed(boolean ready) {
        if (!ready) {

            String key = "";
            if (currentDialog instanceof NonModalDialog) key = ((NonModalDialog) currentDialog).getKey();

            if (currentDialog instanceof AutoSaveLoadDialog) {
                // Not yet a NonModalDialog subclass
                startAutoSaveLoadPoller((AutoSaveLoadDialog) currentDialog);

            } else if (!(currentDialog instanceof NonModalDialog)) {
                log.warn("Unknown dialog action: dialog=[{}] action=[{}]", currentDialog, currentDialogAction);
                currentDialogAction = null;

            } else if (currentDialog instanceof MessageDialog) {
                // Nothing to do.
                currentDialogAction = null;
                // This cancels the currently incomplete user action.
                // WARNING: always do this if dialog processing terminates in a context
                // where an action is aborted and the UI must return to its previous state.
                // This will normally be the case after a CANCEL (but not after a NO).

            } else if (COMPANY_START_PRICE_DIALOG.equals(key)) {

                RadioButtonDialog dialog = (RadioButtonDialog) currentDialog;
                StartCompany action = (StartCompany) currentDialogAction;

                int index = dialog.getSelectedOption();
                if (index >= 0) {
                    int price = action.getStartPrices()[index];
                    action.setStartPrice(price);
                    if (action.getNumberBought() == 0) {
                        // Set bought amount only if it has not been preset
                        // (used in SOH to start a company from phase 3)
                        action.setNumberBought(action.getSharesPerCertificate());
                    }
                } else {
                    // No selection done - no action
                    currentDialogAction = null;
                }

            } else if (EXCHANGE_TOKENS_DIALOG.equals(key)) {

                CheckBoxDialog dialog = (CheckBoxDialog) currentDialog;
                ExchangeTokens action = (ExchangeTokens) currentDialogAction;
                boolean[] exchanged = dialog.getSelectedOptions();
                String[] options = dialog.getOptions();

                int numberSelected = (int) IntStream.range(0, options.length).filter(index -> exchanged[index]).count();

                int minNumber = action.getMinNumberToExchange();
                int maxNumber = action.getMaxNumberToExchange();
                if (numberSelected < minNumber
                        || numberSelected > maxNumber) {
                    if (minNumber == maxNumber) {
                        JOptionPane.showMessageDialog(null,
                                LocalText.getText("YouMustSelect1", minNumber));
                    } else {
                        JOptionPane.showMessageDialog(null,
                                LocalText.getText("YouMustSelect2", minNumber, maxNumber));
                    }
                    exchangeTokens(action);
                    return;

                }
                for (int index = 0; index < options.length; index++) {
                    if (exchanged[index]) {
                        action.getTokensToExchange().get(index).setSelected(true);
                    }
                }
            } else if (REPAY_LOANS_DIALOG.equals(key)) {

                RadioButtonDialog dialog = (RadioButtonDialog) currentDialog;
                RepayLoans action = (RepayLoans) currentDialogAction;
                int selected = dialog.getSelectedOption();
                action.setNumberTaken(action.getMinNumber() + selected);

            } else if (ADJUST_SHARE_PRICE_DIALOG.equals(key)) {
                RadioButtonDialog dialog = (RadioButtonDialog) currentDialog;
                AdjustSharePrice action = (AdjustSharePrice) currentDialogAction;
                EnumSet<AdjustSharePrice.Direction> directions = action.getDirections();
                int selected = dialog.getSelectedOption();
                if (selected > 0) {
                    action.setChosenDirection(
                            (AdjustSharePrice.Direction) directions.toArray()[selected - 1]);
                }

            } else {
                log.warn("Unknown NonModal dialog action: dialog=[{}] action=[{}]", currentDialog, currentDialogAction);
                currentDialogAction = null;
            }
        }

        processAction(currentDialogAction);

    }

    protected void autoSave(String newPlayer) {
        lastSavedFilename = savePrefix + "_" + saveDateTimeFormat.format(new Date()) + "_" + newPlayer + "." + saveExtension;
        GameAction saveAction = new GameAction(getRoot(), GameAction.Mode.SAVE);
        saveAction.setFilepath(saveDirectory + "/" + lastSavedFilename);
        log.debug("Autosaving to {}", lastSavedFilename);
        processOnServer(saveAction);

        saveAutoSavedFilename(lastSavedFilename);
    }

    protected boolean saveAutoSavedFilename(String lastSavedFilename) {
        String lastSavedFilenameFilepath = saveDirectory + "/" + savePrefix + "." + GameUIManager.DEFAULT_SAVE_POLLING_EXTENSION;
        try {
            File f = new File(lastSavedFilenameFilepath);
            PrintWriter out = new PrintWriter(new FileWriter(f));
            out.println(lastSavedFilename);
            out.close();
            return true;
        } catch (IOException e) {
            log.error("Exception whilst autosaving file '{}'", lastSavedFilenameFilepath, e);
            return false;
        }
    }

    protected boolean pollingIsOn() {
        return autoLoadPoller != null && autoLoadPoller.getStatus() == AutoLoadPoller.ON;
    }

    public boolean isMyTurn() {
        return myTurn;
    }

    /**
     * Stub, can be overridden by subclasses
     */
    protected boolean checkGameSpecificDialogAction() {
        return false;
    }

    @Override
    public JDialog getCurrentDialog() {
        return currentDialog;
    }

    @Override
    public PossibleAction getCurrentDialogAction() {
        return currentDialogAction;
    }

    @Override
    public void setCurrentDialog(JDialog dialog, PossibleAction action) {
        if (currentDialog != null) {
            currentDialog.dispose();
        }
        currentDialog = dialog;
        currentDialogAction = action;
    }

    /**
     * Change global font size
     *
     * @param scale
     */
    public void changeGlobalFont(Font replaceFont, double scale) {
        UIDefaults defaults = UIManager.getDefaults();
        Enumeration<Object> keys = defaults.keys();
        while (keys.hasMoreElements()) {
            Object key = keys.nextElement();
            Object value = defaults.get(key);
            if (value instanceof Font) {
                UIManager.put(key, null);
                Font font;
                if (replaceFont != null) {
                    font = replaceFont;
                } else {
                    font = UIManager.getFont(key);
                }
                if (font != null) {
                    float newSize = font.getSize2D() * (float) scale;
                    UIManager.put(key, new FontUIResource(font.deriveFont(newSize)));
                }
            }
        }
    }


    public void exportGame(GameAction exportAction) {
        JFileChooser jfc = new JFileChooser();
        String filename;
        if (providedName != null) {
            filename = providedName;
        } else {
            filename = saveDirectory + "/" + savePrefix + "_"
                    + saveDateTimeFormat.format(new Date()) + "_"
                    + saveSuffix + ".txt";
        }

        File proposedFile = new File(filename);
        jfc.setSelectedFile(proposedFile);

        if (jfc.showSaveDialog(statusWindow) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            String filepath = selectedFile.getPath();
            saveDirectory = selectedFile.getParent();
            if (!selectedFile.getName().equalsIgnoreCase(proposedFile.getName())) {
                providedName = filepath;
            }
            exportAction.setFilepath(filepath);
            processAction(exportAction);
        }
    }

    public void saveGame(GameAction saveAction) {
        // copy latest report buffer entries to clipboard
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        StringSelection reportText = new StringSelection(
                getRoot().getReportManager().getReportBuffer().getRecentPlayer());
        clipboard.setContents(reportText, null);

        JFileChooser jfc = new JFileChooser();
        String filename;
        if (providedName != null) {
            filename = providedName;
        } else {
            String currentSuffix;
            if (NEXT_PLAYER_SUFFIX.equals(saveSuffixSpec)) {
                currentSuffix = getCurrentPlayer().getId().replaceAll("[^-\\w\\.]", "_");
            } else if (CURRENT_ROUND_SUFFIX.equals(saveSuffixSpec)) {
                if (currentRound != null) {
                    currentSuffix = currentRound.getRoundName();
                } else {
                    currentSuffix = "";
                }
            } else {
                currentSuffix = saveSuffix;
            }
            filename = saveDirectory + "/" + savePrefix + "_" + saveDateTimeFormat.format(new Date()) + "_" +
                    currentSuffix + "." + saveExtension;
        }

        File proposedFile = new File(filename);
        jfc.setSelectedFile(proposedFile);

        // allows adjustment of the save dialog title, to add hint about copy to clipboard
        jfc.setDialogTitle(LocalText.getText("SaveDialogTitle"));

        if (jfc.showSaveDialog(statusWindow) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            String filepath = selectedFile.getPath();
            saveDirectory = selectedFile.getParent();
            if (!selectedFile.getName().equalsIgnoreCase(proposedFile.getName())) {
                // User has not accepted the default name but entered a different one.
                // Check the new name. If only the prefix has changed, only remember that part.
                String[] proposedParts = proposedFile.getName().split("_", 2);
                String[] selectedParts = selectedFile.getName().split("_", 2);
                if (proposedParts.length >= 2 && selectedParts.length >= 2 &&
                        !proposedParts[0].equals(selectedParts[0]) &&
                        proposedParts[1].equals(selectedParts[1])) {
                    savePrefix = selectedParts[0];
                } else {
                    // Otherwise, remember and keep using the whole filename.
                    providedName = filepath;
                }
            }
            saveAction.setFilepath(filepath);
            processAction(saveAction);
        }
    }

    public void reloadGame(GameAction reloadAction) {
        JFileChooser jfc = new JFileChooser();
        jfc.setCurrentDirectory(new File(saveDirectory));

        if (jfc.showOpenDialog(statusWindow) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            saveDirectory = selectedFile.getParent();
            reloadAction.setFilepath(selectedFile.getPath());
            processAction(reloadAction);
        } else { // cancel pressed
            return;
        }
    }

    public void autoSaveLoadGame() {
        AutoSaveLoadDialog dialog = new AutoSaveLoadDialog(this,
                autoSaveLoadStatus,
                autoSaveLoadPollingInterval);
        setCurrentDialog(dialog, null);
    }

    public void startAutoSaveLoadPoller(AutoSaveLoadDialog dialog) {
        autoSaveLoadStatus = dialog.getStatus();
        autoSaveLoadPollingInterval = dialog.getInterval();
        startAutoSaveLoadPoller();
    }

    public void startAutoSaveLoadPoller() {
        if (!Util.hasValue(localPlayerName)) {
            // FIXME (Rails2.0) Replace this with something better (DisplayBuffer is not available so far
            // DisplayBuffer.add(this, "You cannot activate AutoSave/Load without setting local.player.name");
            return;
        }
        log.debug("Polling local player name: {}", localPlayerName);
        log.debug("AutoSaveLoad parameters: status={} interval={}", autoSaveLoadStatus, autoSaveLoadPollingInterval);

        if (autoSaveLoadStatus != AutoLoadPoller.OFF) {
            if (!gameWasLoaded) {
                /* The first time (only) we use the normal save process,
                 * so the player can select a directory, and change
                 * the prefix if so desired.
                 */
                GameAction saveAction = new GameAction(getRoot(), GameAction.Mode.SAVE);
                saveSuffix = localPlayerName;
                saveGame(saveAction);
                lastSavedFilename = saveAction.getFilepath();
            }
            if (lastSavedFilename != null) {
                /* Now also save the "last saved file" file */
                autoSaveLoadInitialized = saveAutoSavedFilename(lastSavedFilename);
            }
        }

        if (autoLoadPoller == null && autoSaveLoadStatus > 0) {
            autoLoadPoller = new AutoLoadPoller(this, saveDirectory, savePrefix, lastSavedFilename,
                    localPlayerName, autoSaveLoadStatus, autoSaveLoadPollingInterval);
            autoLoadPoller.start();
        } else if (autoLoadPoller != null) {
            autoLoadPoller.setStatus(autoSaveLoadStatus);
            autoLoadPoller.setPollingInterval(autoSaveLoadPollingInterval);
        }

        if (autoLoadPoller != null) {
            myTurn = getCurrentPlayer().getId().equals(localPlayerName);
            if (!myTurn) {
                // Start autoload polling
                autoLoadPoller.setActive(autoSaveLoadStatus == AutoLoadPoller.ON);
            }
            // TODO: depending on polling state we should enable/disable buttons
            log.debug("MyTurn={} poller status={} active={}", myTurn, autoLoadPoller.getStatus(), autoLoadPoller.isActive());
        }
    }

    public void saveGameStatus() {
        List<String> status = statusWindow.getGameStatus().getTextContents();

        JFileChooser jfc = new JFileChooser();
        String filename = saveDirectory + "/" + savePrefix + "_"
                + saveDateTimeFormat.format(new Date()) + ".status";

        File proposedFile = new File(filename);
        jfc.setSelectedFile(proposedFile);

        if (jfc.showSaveDialog(statusWindow) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            try {
                PrintWriter pw = new PrintWriter(selectedFile);

                for (String line : status) pw.println(line);

                pw.close();

            } catch (IOException e) {
                log.error("Save failed", e);
                getDisplayBuffer().add(LocalText.getText("SaveFailed", e.getMessage()));
            }
        }
    }

    public void setGameFile(File gameFile) {
        saveDirectory = gameFile.getParent();
        lastSavedFilename = gameFile.getName();
    }

    public void setSaveDirectory(String saveDirectory) {
        this.saveDirectory = saveDirectory;
    }

    public PossibleAction getLastAction() {
        return lastAction;
    }

    public RailsRoot getRoot() {
        return railsRoot;
    }

    public GameManager getGameManager() {
        return railsRoot.getGameManager();
    }

    public DisplayBuffer getDisplayBuffer() {
        return railsRoot.getReportManager().getDisplayBuffer();
    }

    public void setORUIManager(ORUIManager orUIManager) {
        this.orUIManager = orUIManager;
    }

    public ORUIManager getORUIManager() {
        return orUIManager;
    }

    public RoundFacade getCurrentRound() {
        return railsRoot.getGameManager().getCurrentRound();
    }

    public boolean isGameOver() {
        return railsRoot.getGameManager().isGameOver();
    }

    public int getNumberOfPlayers() {
        return railsRoot.getPlayerManager().getNumberOfPlayers();
    }

    public PlayerManager getPlayerManager() {
        return railsRoot.getPlayerManager();
    }

    public List<Player> getPlayers() {
        return railsRoot.getPlayerManager().getPlayers();
    }

    public Player getCurrentPlayer() {
        return railsRoot.getPlayerManager().getCurrentPlayer();
    }

    public Player getPriorityPlayer() {
        return railsRoot.getPlayerManager().getPriorityPlayer();
    }

    public Phase getCurrentPhase() {
        return railsRoot.getPhaseManager().getCurrentPhase();
    }

    public List<PublicCompany> getAllPublicCompanies() {
        return railsRoot.getCompanyManager().getAllPublicCompanies();
    }

    public String getClassName(GuiDef.ClassName key) {
        return railsRoot.getGameManager().getClassName(key);
    }

    public Object getGameParameter(GuiDef.Parm key) {
        return railsRoot.getGameManager().getGuiParameter(key);
    }

    public boolean getGameParameterAsBoolean(GuiDef.Parm key) {
        return (Boolean) getGameParameter(key);
    }

    private void setEnabledWindow(boolean enabled, JFrame window, JFrame exceptionWindow) {

        if (window != null && window != exceptionWindow) {
            window.setEnabled(enabled);
        }
    }

    /**
     * deactivate all game windows, except the argument one
     */
    public void setEnabledAllWindows(boolean enabled, JFrame exceptionWindow) {
        // setEnabledWindow(enabled, stockChart, exceptionWindow);
        setEnabledWindow(enabled, reportWindow, exceptionWindow);
        setEnabledWindow(enabled, configWindow, exceptionWindow);
        setEnabledWindow(enabled, orWindow, exceptionWindow);
        setEnabledWindow(enabled, startRoundWindow, exceptionWindow);
        setEnabledWindow(enabled, statusWindow, exceptionWindow);
    }


    private void updateWindowsLookAndFeel() {
        SwingUtilities.updateComponentTreeUI(statusWindow);
        statusWindow.pack();
        SwingUtilities.updateComponentTreeUI(orWindow);
        orWindow.pack();
        SwingUtilities.updateComponentTreeUI(reportWindow);
        reportWindow.pack();
        SwingUtilities.updateComponentTreeUI(configWindow);
        configWindow.pack();
    }

    // Forwards the format() method to the server
    // EV: Not really. The client also knows about the Bank
    // and all static configuration details. All the complexities
    // built around the money format, including the Currency class,
    // look completely redundant to me.
    public String format(int amount) {
        return Bank.format(railsRoot, amount);
    }

    /**
     * Only set frame directly to visible if the splash phase is already over.
     * Otherwise, the splash framework remembers this visibility request and
     * postpones the setVisible to the point in time where the splash is completed.
     */
    public void setMeVisible(JFrame frame, boolean setToVisible) {
        if (splashWindow == null) {
            frame.setVisible(setToVisible);
        } else {
            splashWindow.registerFrameForDeferredVisibility(frame, setToVisible);
        }
    }

    /**
     * Only set frame directly to front if the splash phase is already over.
     * Otherwise, the splash framework remembers this toFront request and
     * postpones the toFront to the point in time where the splash is completed.
     */
    public void setMeToFront(JFrame frame) {
        if (splashWindow == null) {
            frame.toFront();
        } else {
            splashWindow.registerFrameForDeferredToFront(frame);
        }
    }

    /**
     * called when the splash process is completed
     * (and visibility changes are not to be deferred any more)
     */
    public void notifyOfSplashFinalization() {
        splashWindow = null;

        if ( autoSaveLoadStatus > 0 ) {
            SwingUtilities.invokeLater(this::startAutoSaveLoadPoller);
        }
    }

    /**
     * Packs specified frame and tries to apply user defined size afterwards.
     * These actions are performed within the EDT as the caller is assumed to
     * be run by a non-EDT thread.
     */
    public void packAndApplySizing(JFrame frame) {
        final JFrame finalFrame = frame;
        SwingUtilities.invokeLater(new Thread(() -> {
            finalFrame.pack();

            WindowSettings ws = getWindowSettings();
            Rectangle bounds = ws.getBounds(finalFrame);
            if (bounds.x != -1 && bounds.y != -1) finalFrame.setLocation(bounds.getLocation());
            if (bounds.width != -1 && bounds.height != -1) finalFrame.setSize(bounds.getSize());
            ws.set(finalFrame);
        }));
    }

    public List<String> getCurrentGuiPlayerNames() {
        return currentGuiPlayerNames;
    }

    public void saveLogs() {
        LoggerContext lc = (LoggerContext) LoggerFactory.getILoggerFactory();

        CyclicBufferAppender<?> buffer = (CyclicBufferAppender<?>) lc.getLogger(Logger.ROOT_LOGGER_NAME).getAppender("buffer");
        if (buffer == null) {
            log.warn("Unable to find cyclic buffer appender");
            return;
        }

        PatternLayout layout = new PatternLayout();
        layout.setContext(lc);
        layout.setPattern("%d{MM-dd-yyyy:HH:mm:ss.SSS} [%thread] %-5level %logger{10}->%method\\(\\):%line - %msg%n");
        layout.start();

        try {
            PrintWriter writer = new PrintWriter(saveDirectory + "/" +
                    StringUtils.replace(lastSavedFilename, ".rails", "_" + localPlayerName + ".log"));
            int count = buffer.getLength();
            LoggingEvent le;
            for (int i = 0; i < count; i++) {
                le = (LoggingEvent) buffer.get(i);
                writer.print(layout.doLayout(le));
            }
            writer.close();
        } catch (FileNotFoundException e) {
            log.warn("unable to open log output file", e);
        }
    }

    public void saveReportFile() {

        List<String> report = getRoot().getReportManager().getReportBuffer().getAsList();

        JFileChooser jfc = new JFileChooser();
        String filename = saveDirectory + "/" + savePrefix + "_"
                + saveDateTimeFormat.format(new Date()) + ".report";

        File proposedFile = new File(filename);
        jfc.setSelectedFile(proposedFile);

        if (jfc.showSaveDialog(statusWindow) == JFileChooser.APPROVE_OPTION) {
            File selectedFile = jfc.getSelectedFile();
            try {
                PrintWriter pw = new PrintWriter(selectedFile);

                for (String line : report) pw.println(line);

                pw.close();

            } catch (IOException e) {
                log.error("Save failed", e);
                getDisplayBuffer().add(LocalText.getText("SaveFailed", e.getMessage()));
            }
        }

    }

    public class PlayerOrderView implements Observer {
        PlayerOrderView() {
            railsRoot.getPlayerManager().getPlayerOrderModel().addObserver(this);
        }

        public void update(Observable o, Object arg) {
            List<String> newPlayerNames = Arrays.asList(((String) arg).split(";"));
            updatePlayerOrder(newPlayerNames);
        }

        public void deRegister() {
        }

        @Override
        public void update(String text) {
        }

        @Override
        public net.sf.rails.game.state.Observable getObservable() {
            return null;
        }
    }

}
