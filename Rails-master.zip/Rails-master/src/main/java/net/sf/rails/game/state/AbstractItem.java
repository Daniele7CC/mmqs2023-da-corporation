package net.sf.rails.game.state;

import com.google.common.base.MoreObjects;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * An AbstractItem is a default implementation of Item
 */
public abstract class AbstractItem implements Item {

    private final String id;
    private final Item parent;
    private final Context context;

    protected AbstractItem(Item parent, String id) {
        checkNotNull(parent, "Parent cannot be null");
        checkArgument(id != Root.ID, "Id cannot equal " + Root.ID);

        // defined standard fields
        this.parent = parent;
        this.id = id;

        if (parent instanceof Context) {
            context = (Context) parent;
        } else {
            // recursive definition
            context = parent.getContext();
        }

        // add item to context
        context.addItem(this);
    }

    @Override
    public String getId() {
        return id;
    }

    @Override
    public Item getParent() {
        return parent;
    }

    @Override
    public Context getContext() {
        return context;
    }

    @Override
    public Root getRoot() {
        // forward it to the context
        return context.getRoot();
    }

    @Override
    public String getURI() {
        if (parent instanceof Context) {
            return id;
        } else {
            // recursive definition
            return parent.getURI() + Item.SEP + id;
        }
    }

    @Override
    public String getFullURI() {
        // recursive definition
        return parent.getFullURI() + Item.SEP + id;
    }

    @Override
    public String toText() {
        return id;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("URI", getFullURI())
                .toString();
    }

}
