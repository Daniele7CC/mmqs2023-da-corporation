package net.sf.rails.game.specific._18Chesapeake;

import net.sf.rails.game.GameManager;
import net.sf.rails.game.StartRound_1830;

public class StartRound_18Chesapeake extends StartRound_1830 {

	public StartRound_18Chesapeake(GameManager parent, String id) {
		super(parent, id);
		// TODO Auto-generated constructor stub
	}

}
