package net.sf.rails.util;

public class RailsReplayException extends Exception {

    private static final long serialVersionUID = 1L;

    public RailsReplayException(String message) {
        super(message);
    }
    
}
