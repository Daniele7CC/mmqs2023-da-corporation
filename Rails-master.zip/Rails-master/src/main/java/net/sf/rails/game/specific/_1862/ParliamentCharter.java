package net.sf.rails.game.specific._1862;

import net.sf.rails.game.PrivateCompany;
import net.sf.rails.game.RailsItem;

// FIXME: Move static field numberOfPrivateCompanies to CompanyManager

public class ParliamentCharter extends PrivateCompany {

    public ParliamentCharter(RailsItem parent, String id) {
        super(parent, id);
    }
}
