package net.sf.rails.game.specific._18VA;

/**
 * Externalised constants for 18VA
 */

public class GameDef_18VA {

    public final static String GOODS = "GOODS";

}
