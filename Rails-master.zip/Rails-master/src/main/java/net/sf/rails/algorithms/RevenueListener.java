package net.sf.rails.algorithms;

public interface RevenueListener {
    public void revenueUpdate(int revenue, int specialRevenue, boolean finalResult);
}
