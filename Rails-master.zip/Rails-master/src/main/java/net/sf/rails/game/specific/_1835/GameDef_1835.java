package net.sf.rails.game.specific._1835;

public class GameDef_1835 {

    /* Externalised constants */
    public static final String M2_ID = "M2";
    public static final String PR_ID = "PR";
    public static final String BY_ID = "BY";
    public static final String OBB_ID = "OBB";



}
