package net.sf.rails.game.specific._18Chesapeake;

public class GameDef_18Chesapeake {
}
