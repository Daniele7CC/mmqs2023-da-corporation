package net.sf.rails.game.state;

import com.google.common.base.MoreObjects;
import com.google.common.collect.ImmutableSet;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Requirement:
 * The observable object has to call each observer per update() if the object has changed.
 */
public abstract class Observable implements Item {

    // fields for Item implementation
    private final String id;
    private final Item parent;
    private final Context context;

    /**
     * @param parent parent node in item hierarchy (cannot be null)
     * @param id     id of the observable
     *               If id is null it creates an "unobservable" observable
     *               This is required for the creation of states that are themselves stateless
     */

    protected Observable(Item parent, String id) {
        checkNotNull(parent, "Parent cannot be null");
        checkNotNull(id, "Id cannot be null");

        // defined standard fields
        this.parent = parent;
        this.id = id;

        if (parent instanceof Context) {
            context = (Context) parent;
        } else {
            // recursive definition
            context = parent.getContext();
        }

        context.addItem(this);
    }

    // has to be delayed as at the time of initialization the complete link is not yet defined
    protected StateManager getStateManager() {
        return context.getRoot().getStateManager();
    }

    public void addObserver(Observer o) {
        getStateManager().addObserver(o, this);
    }

    public boolean removeObserver(Observer o) {
        return getStateManager().removeObserver(o, this);
    }

    public ImmutableSet<Observer> getObservers() {
        return getStateManager().getObservers(this);
    }

    public void addModel(Model m) {
        getStateManager().addModel(m, this);
    }

    public boolean removeModel(Model m) {
        return getStateManager().removeModel(m, this);
    }

    public ImmutableSet<Model> getModels() {
        return getStateManager().getModels(this);
    }

    public void addTrigger(Triggerable m) {
        getStateManager().addTrigger(m, this);
    }

    public boolean removeTrigger(Triggerable m) {
        return getStateManager().removeTrigger(m, this);
    }

    public ImmutableSet<Triggerable> getTriggers() {
        return getStateManager().getTriggers(this);
    }

    /**
     * Text to delivered to Observers
     * Default is defined to be identical with toString()
     *
     * @return text for observers
     */
    @Override
    public String toText() {
        return this.toString();
    }

    // Item methods

    @Override
    public String getId() {
        return id;
    }

    @Override
    public Item getParent() {
        return parent;
    }

    @Override
    public Context getContext() {
        return context;
    }

    @Override
    public Root getRoot() {
        // forward it to the context
        return context.getRoot();
    }

    @Override
    public String getURI() {
        if (parent instanceof Context) {
            return id;
        } else {
            // recursive definition
            return parent.getURI() + Item.SEP + id;
        }
    }

    @Override
    public String getFullURI() {
        // recursive definition
        return parent.getFullURI() + Item.SEP + id;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(this)
                .add("uri", getFullURI())
                .toString();
    }

}
