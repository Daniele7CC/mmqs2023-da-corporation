package net.sf.rails.game.specific._18Scan;

public class GameDef_18Scan {

    public final static String SJ = "SJ";
    public final static String SJS = "SJS";
    public final static String DSB = "DSB";

}
