package net.sf.rails.game.round;

import net.sf.rails.game.RailsItem;
import net.sf.rails.game.RailsManager;


public class GameManagerNG extends RailsManager  {

    protected GameManagerNG(RailsItem parent, String id) {
        super(parent, id);
    }


}
