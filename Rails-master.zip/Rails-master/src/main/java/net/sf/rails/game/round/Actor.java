package net.sf.rails.game.round;

/** 
 * Actor is the executor of actions (thus usually companies or players)
 */
public interface Actor {

}
