package net.sf.rails.game;

/**
 * Upgrade identifies elements that can be used to upgrade a MapHex
 */
public interface Upgrade {

}
