package net.sf.rails.game.state;


/**
 * A marker for all classes that are the owners of Ownables
 */
public interface Owner extends Item {
    
    
    
}
