package net.sf.rails.game;

public interface Closeable {

    public void close();

    public String getClosingInfo();

}
