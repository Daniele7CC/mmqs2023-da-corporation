package net.sf.rails.game.state;

/**
 * Implement this Interface to indicate that Objects can be created via Reflection
 */
public interface Creatable {
    
}
